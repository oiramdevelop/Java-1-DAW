package unidad4.practica;

import java.sql.Connection;
import java.sql.DriverManager;

public class UtilsBD {
	public static Connection ConectarBD() {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/starwars", "root", "daw2024");

			return con;
		} catch (Exception e) {
			// el printStackTrace muestra el error de la excepcion si ocurre el error
			e.printStackTrace();
		}
		return null;
	}

}
